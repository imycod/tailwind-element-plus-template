import {store} from "../utils";

export const useLogsStore = defineStore({
    id: 'item-logs',
    state: () => ({
        propertyList: [],
        templateList:[]
    }),
    getters: {
        properties: state => state.propertyList,
        templates: state => state.templateList,
    },
    actions: {
        setPropertyList(list: any[]) {
            this.propertyList = list
        },
        setTemplateList(list: any[]) {
            this.templateList = list
        },
    }
})

export default function useLogsStoreHook() {
    return useLogsStore(store)
}