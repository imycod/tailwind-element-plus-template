export {setToken, removeToken, userKey} from "@/utils/auth";
export {router} from "@/routers/index.ts"
export {store} from "@/stores";
