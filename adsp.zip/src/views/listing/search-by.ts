export default function searchBy() {
	const {getSchema} = useSearch()
	const propertyOption = ref([])
	const searchSchema = computed(() => {
		let el = [
			{
				type: 'input',
				name: 'propertyName',
				// options: propertyOption.value,
				placeholder: 'Property',
				clearable: true,
			},
			{
				type:'slot',
				name:'xxx1',
				placeholder: 'XXX',
				render: (h) =>h('div',222)
			},
			{
				type: 'input',
				name: 'templateName',
				// options: [],
				placeholder: 'Template',
				clearable: true,
			},
			{
				type: 'select',
				name: 'status',
				options: getOptions('publishStatus'),
				placeholder: 'Status',
				clearable: true,
			},
			{
				type: 'input',
				name: 'platformName',
				placeholder: 'Platform',
				clearable: true,
			},
			{
				type: 'date',
				name: 'startTime',
				placeholder: 'Date Range',
				clearable: true,
			},
		]
		// ['PROPERTY','TEMPLATE','PLATFORM','TYPE','STATUS','DATE & TIME']
		return el.map(options => getSchema(options)[0])
	})

	return {
		schema:searchSchema,
	}
}