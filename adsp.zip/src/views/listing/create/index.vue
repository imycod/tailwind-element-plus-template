<script setup lang="ts">
import {ArrowLeftBold,ArrowRightBold} from "@element-plus/icons-vue"
import ItemProgress from "@/components/item-progress/index.vue"
import progressHandler from "@/components/item-progress/progress.ts";
import property from "./property.vue"
import template from "./template.vue"
import platform from "./platform.vue"
import Settings from "./settings.vue"
import useLogsStoreHook from "@/stores/modules/logs.ts";

// progress
const { getSchema:getProgressSchema,currentStep,nextStep,previousStep }= progressHandler()
let progressKeys = ['Select Property','Select Template','Select Platform','Post Settings','Complete']
const store = useLogsStoreHook()
function next() {
  if (canProceedToNextStep()) {
    nextStep()
  } else {
    ElMessage.warning('Please complete the current step before proceeding.')
  }
}
function canProceedToNextStep(): boolean {
  if (currentStep.value === 0) {
    return store.properties.length > 0
  }
  if (currentStep.value === 1){
    return store.templates.length > 0
  }
  return true
}

const value = computed(()=>{
  switch (currentStep.value) {
    case 0:
      return property
    case 1:
      return template
    case 2:
      return platform
    case 3:
      return Settings
    default:
      return property
  }
})
const steps = getProgressSchema({
  keys:progressKeys
})
</script>

<template>
  <div>
    <div class="back-row" :class="currentStep && 'mb-6'">
      <item-back></item-back>
    </div>
    <div class="min-h-[610px] flex flex-col xl:flex-row gap-4">
      <div class="flex-1">
        <keep-alive>
          <component :is="value"></component>
        </keep-alive>
      </div>
      <div class="w-px bg-gray-200 dark:bg-gray-700/60" :class="!currentStep && 'xl:mt-[85px]'"></div>
      <div class="w-full xl:w-1/3 relative" :class="!currentStep && 'xl:top-[85px]'">
        <item-progress :schema="steps" :currentStep="currentStep"></item-progress>
        <div class="absolute right-0 flex flex-row w-full" :class="!currentStep ? 'xl:bottom-20' : 'xl:bottom-0'">
          <el-button plain type="primary" class="h-[48px] flex-1" v-if="currentStep > 0 " @click="previousStep"><el-icon class="text-xs m-2"><ArrowLeftBold /></el-icon>Previous Step</el-button>
          <el-button type="primary" class="h-[48px] flex-1 el-button--primary" v-if="currentStep <= steps.length - 1" @click="next">Next Step<el-icon class="text-xs m-2"><ArrowRightBold /></el-icon></el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">

</style>