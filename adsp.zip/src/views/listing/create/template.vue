<script setup lang="ts">
import {Search} from "@element-plus/icons-vue";
import useLogsStoreHook from "@/stores/modules/logs.ts";

const {getSchema}= useSearch()
const schemaSearch = getSchema({
  input:{
    name:'name',
    placeholder:'Template'
  },
})

const state = reactive({
  queryForm:{},
  dataList: [],
  pageList: searchTemplates,
  loading: true,
  pagination: {
    currentPage: 1,
    totalCount: 0,
    pageSize: 10
  },
})
const {getSchema:getColumnSchema,sizeChangeHandle,currentChangeHandle}= useTable(state)
const columns= getColumnSchema({
  keyValue:{
    'TEMPLATE NAME': 'name',
    'INTRODUCTION TO CUBEWORK': 'address2',
    'AMENITIES': 'rentableArea',
    'FEATURES INCLUDE:': 'description',
  },
})

function selectionChangeHandle(value:any[]) {
  useLogsStoreHook().setTemplateList(value)
}
</script>

<template>
  <div>
    <item-search :schema="schemaSearch" v-model="state.queryForm">
      <template #default>
        <el-button class="icon-button w-[30px]">
          <el-icon>
            <Search></Search>
          </el-icon>
        </el-button>
      </template>
    </item-search>
    <item-table selection
                @selection-change="selectionChangeHandle"
                :data="state.dataList"
                max-height="60vh"
                :schema="columns"
                :total="state.pagination.totalCount"
                :size-change="sizeChangeHandle"
                :current-change="currentChangeHandle"
    ></item-table>
  </div>
</template>

<style scoped lang="scss">

</style>