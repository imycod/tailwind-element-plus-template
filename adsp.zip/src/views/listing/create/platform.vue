<script setup lang="tsx">
import {PAGINATION} from "@/constants/pagination.ts";

const {getSchema: getSearchSchema, form} = useSearch()
const schemaSearch =[{
  type:'input',
  name:'name',
  placeholder:'Template'
},{
  type:'input',
  name:'clientId',
  placeholder:'Client ID'
}].map(el=>getSearchSchema(el)[0])

const state = reactive({
  dataList:[],
  queryForm:{},
  isPage:false,
  pageList:()=>{}
})
const {getSchema:getColumnSchema} = useTable(state)
const all =ref(false)
const value = ref(false)
</script>

<template>
  <div>
    <item-simple-search :schema="schemaSearch" v-model="form"></item-simple-search>
    <div class="wrapper-border-table flow-shadow">
      <table class="styled-table">
        <thead>
        <tr>
          <th>
            <el-switch v-model="all"></el-switch>
          </th>
          <th>Name</th>
          <th>Points</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td>
            <el-switch v-model="value"></el-switch>
          </td>
          <td>Dom</td>
          <td>6000</td>
        </tr>
        </tbody>
      </table>
      <div class="p-4 flex justify-between items-center">
        <div class="text-gray-400 text-sm">{{ state.pagination.totalCount }} Results</div>
        <el-pagination
            v-if="false"
            v-model:current-page="state.pagination.currentPage"
            v-model:page-size="state.pagination.pageSize"
            :page-sizes="state.pagination.pageSizes"
            :layout="['prev', 'pager', 'next']"
            :total="state.pagination.totalCount"
        />
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.styled-table {
  border-collapse: collapse;
  font-size: 0.9em;
  width: 100%;

  thead tr {
    @apply dark:bg-black-200 dark:text-gray-300 text-gray-500;
    font-weight: 400;
    font-size: 12px;
    text-align: left;
  }

  th,
  td {
    padding: 12px 15px;
  }

  tbody {
    tr {
      @apply border-solid border-gray-800 dark:hover:bg-black-50;
    }

    td {
      @apply border-b border-solid dark:border-gray-800 ;
    }
  }
}
</style>