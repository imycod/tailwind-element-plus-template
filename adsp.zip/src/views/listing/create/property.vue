<script setup lang="ts">
import {DataType, TabType} from "./types.d"
import {searchProperties} from "@/apis/property.ts";
import useLogsStoreHook from "@/stores/modules/logs.ts";

const props = defineProps({
  data: {
    type: Object as PropType<DataType>,
    default: () => ({tabIndex: 0,currentTab:null})
  },
})

const tabs:TabType[] = [{label: 'Property List'}, {label: 'Selected Property'}]
const tabIndex = ref(0)

const {getSchema} = useSearch()
const schemaSearch = [{type: 'input', name: 'name', placeholder: 'Property'}, {
  type: 'input',
  name: 'address',
  placeholder: 'Address'
}].map(el => getSchema(el)[0])

const state = reactive({
  dataList: [],
  pageList: searchProperties,
  pagination: {
    currentPage: 1,
    totalCount: 0,
    pageSize: 10
  },
  props: {
    item: 'list',
    totalCount: 'totalCount'
  },
  queryForm: {},
  loading: true,
  responseCallback:null,
})
state.responseCallback = (result) => {
  result.data.list = result.data.list.map(el => {
    return {
      ...el,
      address:el.address1 + '\n' +el.address2,
    }
  })
}
const {getSchema: getColumnSchema, sizeChangeHandle, currentChangeHandle,getDataList} = useTable(state)
const columns = getColumnSchema({
  // keys: ['id', 'name', 'address', 'RENTABLE AREA', 'DESCRIPTION'],
  keyValue:{
    'NAME':'name',
    'ADDRESS':'address',
    'RENTABLE AREA':'rentableArea',
    'DESCRIPTION':'description'
  }
})
const store = useLogsStoreHook()
function selectionChangeHandle(val:any[]) {
  store.setPropertyList(val)
}
</script>

<template>
  <div>
    <div class="tabs-row">
      <item-tab :schema="tabs" v-model="tabIndex"></item-tab>
    </div>
    <div v-if="tabIndex === 0">
      <item-simple-search :schema="schemaSearch" v-model="state.queryForm" @search="getDataList"></item-simple-search>
      <div class="add-row flex justify-end">
        <span class="mb-3 text-purple-300 hover:text-purple-400 cursor-pointer">+ Add Property</span>
      </div>
    </div>
    <div v-else class="flex justify-end text-red-500 hover:text-red-600 cursor-pointer mb-2">Remove</div>
    <item-table
        :data="state.dataList"
        :schema="columns"
        selection
        @selection-change="selectionChangeHandle"
        max-height="50vh"
        v-loading="state.loading"
        :current="state.pagination.currentPage"
        :total="state.pagination.totalCount"
        :size-change="sizeChangeHandle"
        :current-change="currentChangeHandle"
        :page-size="state.pagination.pageSize"
    >
      <template #name="{row}">
        <a href="#" class="text-purple-400 underline">{{row['name']}}</a>
      </template>
    </item-table>
  </div>
</template>

<style scoped lang="scss">

</style>