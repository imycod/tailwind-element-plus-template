export type TabType = {
    label: string,
}
export type DataType = {
    $tabIndex: number,
    $currentTab: TabType,
}