<script setup lang="ts">
import ItemTab from "@/components/Tabs.vue";
import {Search} from "@element-plus/icons-vue"
import searchBy from "./search-by.ts"
import listTable from "./list-table.ts";

function create() {
  redirectTo('/listing/create',{
    isReplace:false
  })
}
// tabs
const tabs = [{label: 'Ads Log'}, {label: 'Auto Scheduler'}];
const tableIndex = ref(0)
// table
const {schema: columns, state, sizeChangeHandle, currentChangeHandle,getDataList}=listTable()
// search
const {schema: searchSchema} = searchBy()
</script>
<template>
  <div>
    <div class="top-row flex justify-between items-center">
      <h1 class="title text-[24px]">Listing</h1>
      <el-button type="primary" size="large" @click="create">Create Ads Post</el-button>
    </div>
    <div class="tabs-row">
      <item-tab :schema="tabs" v-model="tableIndex"></item-tab>
    </div>
    <div class="top-nav">
      <item-simple-search :schema="searchSchema" v-model="state.queryForm" @search="getDataList"></item-simple-search>
    </div>
    <item-table
        :data="state.dataList"
        :schema="columns"
        selection
        max-height="50vh"
        v-loading="state.loading"
        :current="state.pagination.currentPage"
        :total="state.pagination.totalCount"
        :size-change="sizeChangeHandle"
        :current-change="currentChangeHandle"
        :page-size="state.pagination.pageSize"
    >
        <template #propertyName="{row, $index}">
          <a class="text-purple-400 underline cursor-pointer"> {{row['propertyName']}}</a>
          <!--        <el-input v-if="$index === 0" v-model="row['propertyName']"></el-input>-->
        </template>
        <template #companyTemplateName="{row}">
          <a class="text-purple-400 underline cursor-pointer"> {{row['companyTemplateName']}}</a>
        </template>
    </item-table>
  </div>
</template>

<style scoped lang="scss">
</style>