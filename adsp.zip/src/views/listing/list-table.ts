import {QueryLogType} from "@/apis/types";

export default function listTable() {
	const state = reactive({
		loading: true,
		isPage: true,
		format:{
			createAt:'publishDatetime'
		},
		responseCallback:null,
		dataList: [],
		columns: [],
		queryForm: {} as QueryLogType,
		pageList: searchLogs,
	})
	state.responseCallback = (result) => {
		result.data.list =  result.data.list.map(item=>{
			return {
				...item,
				typeName:getNameByList(getOptions('publishType'),item.type),
				statusName:getNameByList(getOptions('publishStatus'),item.status)
			}
		})
	}
	const {
		getDataList,
		getSchema: getColumnSchema,
		currentChangeHandle,
		sizeChangeHandle,
	} = useTable(state)
	const columns = getColumnSchema({
		// exclude: ['id', 'name', 'email'],
		// columnKeys:['id', 'name', 'email']
		// keys:['PROPERTY','TEMPLATE','PLATFORM','TYPE','STATUS','DATE & TIME'],
		keyValue: {
			'PROPERTY': 'propertyName',
			'TEMPLATE': 'companyTemplateName',
			'PLATFORM': 'platformName',
			'TYPE': 'typeName',
			'STATUS': 'statusName',
			'DATE & TIME': 'publishDatetime',
		}
	})
	return {
		schema: columns,
		state,
		getDataList,
		currentChangeHandle,
		sizeChangeHandle,
	}
}