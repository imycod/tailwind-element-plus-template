<script setup lang="ts">
import {googleLogin as googleLoginApi} from "@/apis/login.ts"
import {loginWithGoogle} from "@/utils/third-party-login.ts";

function signUp() {

}

const route = useRoute()
// 第三方登录
const LOGIN_WITH_MAP = {
  GOOGLE: googleLogin
}

function googleLogin() {
  loginWithGoogle()
      .then(googleLoginApi)
      .then(async result => {
        if (result.success) {
          setToken({
            oAuthToken: result.oAuthToken,
            accessToken: result.accessToken,
          })
          const resAuth = await toAuth()
          if (resAuth) {
            // resAuth.oAuthToken
            setSessionItem(tokenKey, result.accessToken)
            redirectTo('/')
          }
        }
      })
}

const loginWith = (key) => LOGIN_WITH_MAP[key]()
</script>

<template>
  <!--    or -->
  <div class="flex items-center gap-1 text-gray-300 justify-center">
    <div class="bg-gray-300 h-[1px] w-full"></div>
    <div>{{ $t('OR') }}</div>
    <div class="bg-gray-300 h-[1px] w-full"></div>
  </div>
  <!--     sign up   -->
  <div class="flex justify-center">
    {{ $t('Don not have an account') }}
    <span
        class="text-customBlue cursor-pointer ml-[4px] dark:text-purple-300"
        @click="signUp"
    >
        {{ $t('Sign up') }}
    </span>
  </div>
  <!--    google    -->
  <div class="flex flex-col justify-center">

  </div>
  <!--  copyright -->
  <span class="text-center text-[12px] mt-5 justify-center">
    {{ $t('Copyright') }} © Ads Poster {{ new Date().getFullYear() }}
  </span>
</template>
