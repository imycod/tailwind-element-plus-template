<script setup lang="ts">

</script>

<template>
  <div>
    500
  </div>
</template>

<style scoped lang="scss">

</style>