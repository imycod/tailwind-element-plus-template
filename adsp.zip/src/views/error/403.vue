<script setup lang="ts">

</script>

<template>
  <div>
    403
  </div>
</template>

<style scoped lang="scss">

</style>