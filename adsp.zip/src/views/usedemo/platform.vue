<script setup lang="tsx">

</script>

<template>
  <div>
    <item-search-form :columns="columns" :searchParam="searchParam" search-col="xl"></item-search-form>
    <div class="wrapper-border-table flow-shadow">
      <table class="styled-table">
        <thead>
        <tr>
          <th>
            <el-switch v-model="value"></el-switch>
          </th>
          <th>Name</th>
          <th>Points</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td>
            <el-switch v-model="value"></el-switch>
          </td>
          <td>Dom</td>
          <td>6000</td>
        </tr>
        </tbody>
      </table>
      <div class="m-4">
        <div class="text-gray-400 text-sm">9 Results</div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.styled-table {
  border-collapse: collapse;
  font-size: 0.9em;
  width: 100%;

  thead tr {
    @apply dark:bg-black-200;
    color: var(--gray-300);
    font-weight: 400;
    font-size: 12px;
    text-align: left;
  }

  th,
  td {
    padding: 12px 15px;
  }

  tbody {
    tr {
      @apply border-solid border-gray-800;
    }

    td {
      @apply dark:bg-black-400 border-b border-solid dark:border-gray-800;
    }
  }
}
</style>