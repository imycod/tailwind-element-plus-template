<template>
  <div class="item-layout-menu">
    <div class="ml-[14px] my-[20px] flex justify-between items-center">
      <div class="h-[50px] flex-1" :class="isCollapse?'logo':'logo-full'"/>
      <div class="flex justify-between w-[70px]" v-if="!isCollapse">
        <div class="rounded-lg bg-black-100 hover:cursor-pointer p-2"><img src="@/assets/svg/nav.svg"></div>
        <div class="rounded-lg bg-black-100 hover:cursor-pointer p-2"><img src="@/assets/svg/nav1.svg"></div>
      </div>
    </div>
    <i-sidebar router :collapse="isCollapse" :class="[!isCollapse && 'w-[320px]']"
               :data="routesMenu"></i-sidebar>
  </div>
</template>

<script lang="ts" setup>
import {useWindowSize} from '@vueuse/core'
import {Sidebar as ISidebar} from "unisc-item-ui"
import "unisc-item-ui/es/sidebar/style/index.css"
import {routes} from "@/routers"

let routesMenu = routes[0].children.map((routes, index) => {
  return {
    ...routes,
    title: routes.name,
    index: routes.path,
    icon: routes.meta.icon,
    children: routes.children && handleMenu(routes.children)
  }
})

function handleMenu(menu) {
  return menu.map(routes => {
    return {
      ...routes,
      title: routes.name,
      index: routes.path,
      icon: routes.meta.icon,
    }
  })
}


const isCollapse = ref(false)
const {width} = useWindowSize()
const stop = watchEffect(() => {
  if (width.value < 1024) { // tailwind screens break point
    isCollapse.value = true
  } else {
    isCollapse.value = false
  }
})

onUnmounted(() => {
  stop()
})
onMounted(() => {
})
</script>

<style lang="scss" scoped>
.item-layout-menu {
  border-right: none;
  height: 100%;
  padding: 10px 10px;
  background-color: var(--item-menu-bg-color);

  .dark {
    .logo-full {
      background: url("@/assets/svg/logos-product.svg") no-repeat !important;
    }
  }

  .logo-full {
    background: url("@/assets/svg/logos-product.svg") no-repeat;
  }

  .logo {
    background: url("@/assets/svg/logo.svg") no-repeat;
  }
}
</style>