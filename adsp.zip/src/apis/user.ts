export const getUserInfo = () =>
    http.get("/passApi/api/idm-app/user");

export const getUsers = (data) => http.post("/api/idm-app/users",{data},{
    headers:{
        Accept:'application/json'
    }
});