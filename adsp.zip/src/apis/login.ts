export const googleLogin = (data: any) =>
  http.post(`/passApi/idm-app/user/google/login`, data);
