import {DataPropertiesType} from "@/apis/types";

export const searchProperties = (data:DataPropertiesType) => http.post("/api/property/search-by-paging",{data})
