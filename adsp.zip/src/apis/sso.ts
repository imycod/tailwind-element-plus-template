export const login = (body: any) =>
    http.post("/passApi/api/idm-app/user/sso/login", body);
export const authorize = (body: any, config: any) =>
    http.post("/passApi/api/idm-app/user/sso/auth", body, config);
export const logout = (body: any) =>
    http.post("/passApi/api/idm-app/user/sso/logout", body);
