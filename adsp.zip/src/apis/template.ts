import {DataTemplateType} from "@/apis/types";

export const searchTemplates = (data:DataTemplateType) => http.post("/api/template/search-by-paging",{data})
