const Layout = () => import("@/layout/index.vue");

import listingIcon from "@/assets/svg/listing.svg";
import propertyIcon from "@/assets/svg/property.svg";
import platformIcon from "@/assets/svg/platform.svg";
import systemIcon from "@/assets/svg/system.svg";

export default {
  path: "/",
  component: Layout,
  redirect: "/listing",
  children: [
    {
      path: "/listing",
      name: "Listing",
      component: () => import("@/views/listing/index.vue"),
      meta: {
        icon: listingIcon,
      },
      // children:[
      //   {
      //     path: "/listing",
      //     name: "Listing",
      //     component: () => import("@/views/listing/index.vue"),
      //     meta: {
      //       icon: listingIcon,
      //     },
      //   }
      // ]
    },
    {
      path: "/property",
      name: "Property Management",
      component: () => import("@/views/property/index.vue"),
      meta: {
        icon: propertyIcon,
      },
    },
    {
      path: "/template",
      name: "Listing Template",
      component: () => import("@/views/template/index.vue"),
      meta: {
        icon: platformIcon,
      },
    },
    // {
    //   path: "/setting",
    //   redirect: "/setting/department",
    //   meta: {
    //     icon: "Cog6Tooth",
    //     bottom:true,
    //   },
    //   name: "Setting",
    //   children: [
    //     {
    //       path: "/setting/department",
    //       name: "Department",
    //       component: () => import("@/views/setting/department/index.vue"),
    //       meta: {
    //
    //       },
    //     },
    //   ],
    // },
  ],
};
