import {toLoginPage} from "@/utils/sso.ts";
const Layout = () => import("@/layout/index.vue");

export default [
    {
        path: "/listing/create",
        component: Layout,
        redirect: "/listing",
        children:[
            {
                path: "/listing/create",
                name: "Create Listing",
                component: () => import("@/views/listing/create/index.vue"),
            }
        ]
    },
    {
        path: "/login",
        name: "Login",
        component: () => import("@/views/login/index.vue"),
        meta: {
            title: "login",
        },
        beforeEnter: (to, from, next) => {
            const {VITE_NODE_ENV, VITE_IS_SSO} = import.meta.env
            const token = getSessionItem(tokenKey)
            if (token) {
                next('/')
                return;
            }
            if (VITE_NODE_ENV === "development") {
                if (VITE_IS_SSO === "true") {
                    toLoginPage()
                    return
                }
                next()
            } else {
                toLoginPage()
            }
        }
    }, {
        path: "/accountProfile",
        name: "accountProfile",
        component: () => import("@/views/login/index.vue"),
        meta: {
            title: "Account Profile",
            iframe: true,
            skipAuth: true,
        }
    }
    // {
    //   path: "/redirect",
    //   component: Layout,
    //   meta: {
    //     title: "加载中...",
    //     showLink: false,
    //     rank: 102
    //   },
    //   children: [
    //     {
    //       path: "/redirect/:path(.*)",
    //       name: "Redirect",
    //       component: () => import("@/layout/redirect.vue")
    //     }
    //   ]
    // },
    // {
    //   path: "/:pathMatch(.*)*",
    //   // redirect: '/',
    //   name: "404",
    //   component: () => import("@/views/error/404.vue"),
    //   meta: {
    //     title: "404"
    //   }
    // }
];
