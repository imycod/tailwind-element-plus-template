import {remainingPaths} from "@/routers";
import {setSessionItem} from "@/utils/auth.ts";

export function createStateGuard(router,isInit) {
    router.beforeEach(async (to, from, next) => {
        if (remainingPaths.includes(to.path)){
            next()
            return
        }
        if (isInit){
           const { token } =  to.query
            if (token){
                setSessionItem(tokenKey,token)
            }
            // 清理缓存
            // 初始化数据 比如header query数据
            console.log('createStateGuard')
            isInit = false
        }
        next();
    });
}