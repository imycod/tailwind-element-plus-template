// 动态字典接口
const ax = http

export const getCountryList = () => {
	return ax.post('/api/bam/open-api/address/country/search/item', {});
};

export const getCountryStateList = (countryCode: string) => {
	return ax.post('/api/bam/open-api/address/state/search/item', { countryCode });
};

