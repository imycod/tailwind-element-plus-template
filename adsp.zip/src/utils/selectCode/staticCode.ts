// 静态字典数据

const staticCode: Record<string, any> = {
	// example
	// category: ['WEB', 'ANDROID', 'API', 'ALL', 'MOBILE'],
	// liveSupport: {
	// 	INACTIVE: 'Not Supported',
	// 	ALLOW_ADDITIONAL: 'Monthly Charge',
	// 	ACTIVE: 'Include in plan charge',
	// },
	publishType:{
		1:'Manual',
		0:'Automatic'
	},
	publishStatus: {
		0:'Fail',
		1:'Success',
	},
};

export default staticCode;
