import Cookies from "js-cookie";
import {useSessionStorage} from "@vueuse/core";
import type {AuthResponse} from "@/utils/types.d";

export const tokenKey = "token";
export const oAuthTokenKey = "oAuthToken";
export const authorizeTokenKey = "authorizeToken";
export const userKey = "userInfo";

export function getItem(key?: string, value: any = null) {
    key = key || userKey;
    return useSessionStorage(key, value).value;
}

export function setSessionItem(key: string, value: any = null) {
    if (!key) {
        throw new Error("请输入session key");
    }
    return useSessionStorage(key, value);
}

export function getSessionItem(key: string, value: any = null) {
    return useSessionStorage(key, value).value;
}

export function removeSession(key: string, value: any = null) {
    return useSessionStorage(key, value)
}

export function getToken(): AuthResponse {
    return Cookies.get(oAuthTokenKey) ?? '';
}

export function setToken(data: AuthResponse) {
    const {oAuthToken} = data;

    Cookies.set(oAuthTokenKey, oAuthToken);
}

export function removeToken() {
    Cookies.remove(oAuthTokenKey);
    useSessionStorage(userKey, null)
}
