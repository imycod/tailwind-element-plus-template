import { removeToken, getToken } from "@/utils/auth.ts";
import type { AuthResponse, LoginBody, LoginResponse } from "@/utils/types.d";
import { redirectTo } from "@/utils/navigation.ts";
import { logout } from "@/apis/sso.ts";
import { router } from "@/routers/index.ts";

const {VITE_PASS_URL,VITE_APP_CODE} = import.meta.env

const USER_FROZEN = 46013;
const NO_PERMISSION = 500;

const browser = getAgent();
const system = {
  channel: "Web",
  platform: "Web",
  device: `${browser.getOS().name} ${browser.getOS().version} ${
    browser.getBrowser().name
  }-${browser.getBrowser().version}`,
};
const applicationCode = VITE_APP_CODE;
export const toLogin = (body: LoginBody) => {
  return new Promise<LoginResponse>(async (resolve, reject) => {
    try {
      const result = await login({
        data: {
          ...body,
          ...system,
          applicationCode,
        },
      });
      resolve(result);
    } catch (error) {
      // 是否冻结
      reject(error);
    }
  });
};

export const toAuth = (token?: string) => {
  const accessToken = token;

  const route = useRoute() || router.currentRoute.value;
  const query = route.query;

  return new Promise<AuthResponse>(async (resolve, reject) => {
    try {
      const result = await authorize(
        {
          data: {
            ...system,
          },
        },
        {
          headers: {
            "application-code": VITE_APP_CODE,
            Authorization: `${accessToken}`,
          },
        }
      );

      resolve(result);
    } catch (error) {
      if (error.response.status === NO_PERMISSION) {
        // 没权限
        redirectTo("/error/403");
      } else {
        // 过期了
        removeToken();
      }
      reject(error);
    }
  });
};

export function toLogout() {
  return new Promise(async (resolve, reject) => {
    const { oAuthToken } = getToken();
    try {
      await logout({
        ...system,
        oauthToken: oAuthToken,
      });
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
}

export function toLoginPage(){
  redirectTo(`${VITE_PASS_URL}/sso?redirect_url=${encodeURIComponent(window.location.origin)}&applicationCode=${VITE_APP_CODE}`)
}