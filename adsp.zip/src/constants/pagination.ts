export const PAGINATION = {
    current: 1,
    size: 10,
    total: 0,
    pageSizes: [5, 10, 15, 20],
    layout: 'total, sizes, prev, pager, next, jumper',
}