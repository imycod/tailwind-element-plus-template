export const colors = {
  white: {
    DEFAULT: '#ffffff',
    100: '#ffffff',
    300: '#F2F2F7', // menu
    400: '#F9F9F9',
  },
  black: {
    DEFAULT: '#000000',
    50: '#333847', // fill blank
    100: '#2B2F3B',
    200: '#23262F', // block card
    300: '#21232B', // menu bar
    400: '#1B1C23', // bg
    500: '#121217',
  },
  gray: {
    50: '#F9FAFB',
    100: '#F3F4F6',
    200: '#E5E7EB',
    300: '#B3B4B5', // BFC4CD
    400: '#9CA3AF',
    500: '#88898B', //#6B7280
    600: '#4B5563',
    700: '#374151',
    800: '#1F2937',
    900: '#111827',
    950: '#030712',
  },
  "purple": {
    "50": "#e9d9fd",
    "100": "#d3b2fa",
    "200": "#c89ff9",
    "300": "#bc8bf8",
    "400": "#b178f7",
    "500": "#9b51f5", // primary color
    "600": "#852bf3", // scondary color
    "700": "#7a18f2",
    "800": "#700de7",
    "900": "#5d0bc1",
    "950": "#4d00ba"
  },
};


/**
 * Convert hex color to rgb
 * @param hex
 * @returns {[r: number, b: number, g: number]|null}
 */
const hexReg = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})/i

export function hexToRgb(hex) {
  const result = hexReg.exec(hex)
  return result ? [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16),
  ] : null
}


export function convertColorsToCSSVariables(colors, prefix = '') {
  const result = {};

  for (const [key, value] of Object.entries(colors)) {
    const newKey = prefix ? `${prefix}-${key}` : `--${key}`;
    if (typeof value === 'object') {
      Object.assign(result, convertColorsToCSSVariables(value, newKey));
    } else {
      const newKey = key === 'DEFAULT' ? `${prefix}` : `${prefix}-${key}`;
      result[newKey] = value;
    }
  }

  return result;
}


