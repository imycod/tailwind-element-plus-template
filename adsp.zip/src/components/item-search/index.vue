<script setup lang="ts">
import {Search} from "@element-plus/icons-vue";

const props = defineProps({
  schema: {
    type: Array,
    default: () => ([]),
    required: true,
  },
})
const form = defineModel({
  type:Object,
  required: true,
  default: () => {
  }
})

const emits = defineEmits(['search'])
function search() {
  emits('search')
}
</script>

<template>
  <item-wrapper-search>
    <item-form :schema="schema" v-model="form">
      <template #action>
        <el-button class="icon-button w-[36px] rounded-lg" @click="search">
          <el-icon>
            <Search/>
          </el-icon>
        </el-button>
      </template>
    </item-form>
  </item-wrapper-search>
</template>

<style scoped lang="scss">

</style>