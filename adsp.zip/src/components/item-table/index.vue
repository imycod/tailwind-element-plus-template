<script setup lang="ts">
import {PAGINATION} from "@/constants/pagination.ts"

defineOptions({
  name: 'ItemTable'
})

const props = defineProps({
  index: {
    type: Boolean,
    default: false
  },
  selection: {
    type: Boolean,
    default: false
  },
  data: {
    type: Array,
    default: () => []
  },
  schema: {
    type: Array,
    default: () => []
  },
  total: {
    type: Number,
    default: 0
  },
  disabled: {
    type: Boolean,
    default: false
  },
  background: {
    type: Boolean,
    default: false
  },
  sizeChange: {
    type: Function,
    default: () => {
    }
  },
  currentChange: {
    type: Function,
    default: () => {
    }
  },
  currentPage: {
    type: Number,
    default: 1
  },
})
const currentPage = defineModel('currentPage', {
  type: Number,
  default: PAGINATION.current
})
const pageSize = defineModel('pageSize', {
  type: Number,
  default: PAGINATION.size
})
const pageSizes = PAGINATION.pageSizes
// const emit = defineEmits(['update:currentPage','update:pageSize'])
// const currentPage = useVModel(props,'currentPage',emit)
// const pageSize = useVModel(props,'pageSize',emit)
</script>

<template>
  <div class="flow-shadow dark:border rounded-md dark:border-gray-700">
    <el-table v-bind="$attrs" class="item-custom-table" border :data="data">
      <el-table-column v-if="index" type="index" width="50"></el-table-column>
      <el-table-column v-if="selection" type="selection" width="50"></el-table-column>
      <el-table-column v-for="(item, index) in schema" :key="index" :prop="item.key"
                       :label="item.title">
        <template #default="{row, column, $index}">
          <slot :name="item.prop" :row="row" :column="column" :$index="$index"> {{ row[item.prop] }}</slot>
        </template>
      </el-table-column>
    </el-table>
    <div class="flex w-full justify-between items-center h-[50px] px-5">
      <div class="text-gray-400 text-sm">{{ total }} Results</div>
      <div class="flex">
        <div class="flex items-center">
          <div class="relative text-white rounded-md inline-flex items-center px-3 py-2">
            <label for="select-dropdown" class="mr-3 text-sm font-bold">{{ $t('Show') }}:</label>
            <el-select
                v-model="pageSize"
                class="page-select mr-1"
                @change="sizeChange"
            >
              <el-option
                  v-for="(item, index) in pageSizes"
                  :key="index"
                  :label="item"
                  :value="item"
              />
            </el-select>
          </div>
        </div>
        <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="pageSizes"
            :disabled="disabled"
            :background="background"
            layout="prev, pager, next"
            :total="total"
            @size-change="sizeChange"
            @current-change="currentChange"
        />
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">

</style>