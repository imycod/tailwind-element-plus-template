<script setup lang="ts">

</script>

<template>
  <div class="flow-shadow dark:bg-black-200 rounded-lg p-4 mb-4">
    <p class="text-gray-300 text-xs mb-3">{{ $t('SEARCH BY') }}</p>
    <slot></slot>
  </div>
</template>

<style scoped lang="scss">

</style>