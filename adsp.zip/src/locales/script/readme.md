### [WEB] item 项目 集成多语言json和table表格通用互转脚本和脚本使用说明

https://wiki.logisticsteam.com/pages/viewpage.action?pageId=92999455

### [WEB] i18n多语言切换 及 iframe传参 统一对接方式实现

https://wiki.logisticsteam.com/pages/viewpage.action?pageId=92999000

### [execl] i18n线上表格
https://docs.google.com/spreadsheets/d/1yDX8-RbcK7R5HCSVd70NSUJiIoX6hpCPOVUf2SCigD0/edit?gid=295134178#gid=295134178
先把线上表格最新的数据，下载到locals/script文件下，执行脚本即可

### [i8n] 脚本命令实现参考
https://blog.csdn.net/mzpmzk/article/details/79318029